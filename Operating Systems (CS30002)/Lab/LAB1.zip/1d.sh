for FILE in ./1.d.files/*.txt
do
	COUNT=0
	for line in FILE
	do
		ARR[COUNT]=`expr 0 + $line`
		COUNT=`expr 1 + $COUNT`
	done

	
done